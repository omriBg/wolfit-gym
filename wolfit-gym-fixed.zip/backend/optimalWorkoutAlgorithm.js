// backend/optimalWorkoutAlgorithm.js
// אלגוריתם הונגרי מלא ומתוקן לאופטימליות מקסימלית

// מיפוי ספורטים (תואם לשרת)
const SPORT_MAPPING = {
  1: 'כדורגל',
  2: 'כדורסל',  
  3: 'טיפוס',
  4: 'חדר כושר',
  5: 'קורדינציה',
  6: 'טניס',
  7: 'פינגפונג',
  8: 'ריקוד',
  9: 'אופניים'
};

// אלגוריתם הונגרי מלא ומתוקן לאופטימליות מקסימלית
class OptimalHungarianAlgorithm {
  constructor(matrix) {
    this.originalMatrix = matrix.map(row => [...row]);
    this.matrix = matrix.map(row => [...row]);
    this.n = this.matrix.length;
    this.rowCovered = new Array(this.n).fill(false);
    this.colCovered = new Array(this.n).fill(false);
    this.assignment = new Array(this.n).fill(-1);
    this.starredZeros = new Set();
    this.primedZeros = new Set();
    this.path = [];
    
    console.log('🔥 מתחיל אלגוריתם הונגרי אופטימלי מלא');
    console.log('גודל מטריצה:', this.n + 'x' + this.n);
  }

  solve() {
    // Step 1: Reduce matrix by subtracting row and column minimums
    this.reduceMatrix();
    
    let step = 2;
    let iterations = 0;
    const maxIterations = this.n * this.n;
    
    while (step !== 6 && iterations < maxIterations) {
      console.log(`🔄 שלב ${step}, איטרציה ${iterations}`);
      
      switch (step) {
        case 2: step = this.findInitialZeros(); break;
        case 3: step = this.coverStarredColumns(); break;
        case 4: step = this.findUncoveredZero(); break;
        case 5: step = this.constructAugmentingPath(); break;
      }
      iterations++;
    }
    
    if (step === 6) {
      console.log('✅ אלגוריתם הונגרי הושלם בהצלחה');
      console.log('מספר איטרציות:', iterations);
      this.extractAssignment();
      return this.assignment;
    } else {
      console.log('❌ אלגוריתם הונגרי לא התכנס');
      return this.createFallbackAssignment();
    }
  }

  reduceMatrix() {
    console.log('🔧 מפחית מטריצה...');
    
    // Subtract row minimums
    for (let i = 0; i < this.n; i++) {
      const finiteValues = this.matrix[i].filter(val => val < Infinity);
      if (finiteValues.length > 0) {
        const minVal = Math.min(...finiteValues);
        if (minVal > 0) {
          for (let j = 0; j < this.n; j++) {
            if (this.matrix[i][j] < Infinity) {
              this.matrix[i][j] -= minVal;
            }
          }
        }
      }
    }
    
    // Subtract column minimums
    for (let j = 0; j < this.n; j++) {
      const column = [];
      for (let i = 0; i < this.n; i++) {
        if (this.matrix[i][j] < Infinity) {
          column.push(this.matrix[i][j]);
        }
      }
      
      if (column.length > 0) {
        const minVal = Math.min(...column);
        if (minVal > 0) {
          for (let i = 0; i < this.n; i++) {
            if (this.matrix[i][j] < Infinity) {
              this.matrix[i][j] -= minVal;
            }
          }
        }
      }
    }
  }

  findInitialZeros() {
    console.log('🔍 מחפש אפסים ראשוניים...');
    
    this.starredZeros.clear();
    this.primedZeros.clear();
    
    for (let i = 0; i < this.n; i++) {
      for (let j = 0; j < this.n; j++) {
        if (this.matrix[i][j] === 0 && !this.rowCovered[i] && !this.colCovered[j]) {
          this.starredZeros.add(`${i},${j}`);
          this.rowCovered[i] = true;
          this.colCovered[j] = true;
        }
      }
    }
    
    this.clearCovers();
    return 3;
  }

  coverStarredColumns() {
    console.log('⭐ מכסה עמודות עם אפסים מסומנים...');
    
    let coveredColumns = 0;
    for (let j = 0; j < this.n; j++) {
      for (let i = 0; i < this.n; i++) {
        if (this.starredZeros.has(`${i},${j}`)) {
          this.colCovered[j] = true;
          coveredColumns++;
          break;
        }
      }
    }
    
    if (coveredColumns >= this.n) {
      return 6; // סיום
    }
    
    return 4;
  }

  findUncoveredZero() {
    console.log('🔍 מחפש אפס לא מכוסה...');
    
    for (let i = 0; i < this.n; i++) {
      for (let j = 0; j < this.n; j++) {
        if (this.matrix[i][j] === 0 && !this.rowCovered[i] && !this.colCovered[j]) {
          this.primedZeros.add(`${i},${j}`);
          
          // בדיקה אם יש אפס מסומן בשורה
          let starredInRow = false;
          for (let k = 0; k < this.n; k++) {
            if (this.starredZeros.has(`${i},${k}`)) {
              this.rowCovered[i] = true;
              this.colCovered[k] = false;
              starredInRow = true;
              break;
            }
          }
          
          if (!starredInRow) {
            return 5; // בניית נתיב
          }
        }
      }
    }
    
    // לא נמצא אפס לא מכוסה - צריך לחסר מינימום
    this.addMinimumValue();
    return 4;
  }

  constructAugmentingPath() {
    console.log('🛤️ בונה נתיב הרחבה...');
    
    // מציאת האפס הפריים האחרון
    let primeZero = null;
    for (const zero of this.primedZeros) {
      primeZero = zero;
    }
    
    if (!primeZero) {
      return 4;
    }
    
    const [row, col] = primeZero.split(',').map(Number);
    this.path = [[row, col]];
    
    // בניית הנתיב
    let currentRow = row;
    let currentCol = col;
    
    while (true) {
      // חיפוש אפס מסומן בעמודה
      let starredInCol = null;
      for (let i = 0; i < this.n; i++) {
        if (this.starredZeros.has(`${i},${currentCol}`)) {
          starredInCol = [i, currentCol];
          break;
        }
      }
      
      if (!starredInCol) {
        break;
      }
      
      this.path.push(starredInCol);
      
      // חיפוש אפס פריים בשורה
      let primedInRow = null;
      for (let j = 0; j < this.n; j++) {
        if (this.primedZeros.has(`${starredInCol[0]},${j}`)) {
          primedInRow = [starredInCol[0], j];
          break;
        }
      }
      
      if (!primedInRow) {
        break;
      }
      
      this.path.push(primedInRow);
      currentCol = primedInRow[1];
    }
    
    // עדכון האפסים
    this.updateZeros();
    this.clearCovers();
    this.clearPrimes();
    
    return 3;
  }

  updateZeros() {
    console.log('🔄 מעדכן אפסים...');
    
    for (let i = 0; i < this.path.length; i += 2) {
      const [row, col] = this.path[i];
      this.starredZeros.add(`${row},${col}`);
    }
    
    for (let i = 1; i < this.path.length; i += 2) {
      const [row, col] = this.path[i];
      this.starredZeros.delete(`${row},${col}`);
    }
  }

  clearCovers() {
    this.rowCovered.fill(false);
    this.colCovered.fill(false);
  }

  clearPrimes() {
    this.primedZeros.clear();
  }

  addMinimumValue() {
    console.log('➕ מוסיף ערך מינימלי...');
    
    let minVal = Infinity;
    for (let i = 0; i < this.n; i++) {
      for (let j = 0; j < this.n; j++) {
        if (!this.rowCovered[i] && !this.colCovered[j] && this.matrix[i][j] < minVal) {
          minVal = this.matrix[i][j];
        }
      }
    }
    
    for (let i = 0; i < this.n; i++) {
      for (let j = 0; j < this.n; j++) {
        if (this.rowCovered[i]) {
          this.matrix[i][j] += minVal;
        }
        if (!this.colCovered[j]) {
          this.matrix[i][j] -= minVal;
        }
      }
    }
  }

  extractAssignment() {
    console.log('📋 מחלץ השמה...');
    
    for (let i = 0; i < this.n; i++) {
      for (let j = 0; j < this.n; j++) {
        if (this.starredZeros.has(`${i},${j}`)) {
          this.assignment[i] = j;
          break;
        }
      }
    }
  }

  createFallbackAssignment() {
    console.log('🆘 יוצר השמה חלופית...');
    
    const assignment = new Array(this.n).fill(-1);
    const used = new Array(this.n).fill(false);
    
    for (let i = 0; i < this.n; i++) {
      for (let j = 0; j < this.n; j++) {
        if (!used[j] && this.originalMatrix[i][j] < Infinity) {
          assignment[i] = j;
          used[j] = true;
          break;
        }
      }
    }
    
    return assignment;
  }
}

// מערכת שיבוץ אימונים אופטימלית מלאה
class CompleteOptimalWorkoutScheduler {
  constructor(timeSlots, fieldsByTime, userPreferences) {
    this.timeSlots = timeSlots;
    this.fieldsByTime = fieldsByTime;
    this.userPreferences = userPreferences || [];
    this.availableSports = this.extractAvailableSports();
    this.maxUsagePerSport = 2;
    
    console.log('🚀 מערכת שיבוץ אופטימלית נוצרה:');
    console.log('⏰ זמנים:', this.timeSlots.length);
    console.log('🏃 ספורטים זמינים:', this.availableSports);
    console.log('❤️ העדפות משתמש:', this.userPreferences);
  }

  extractAvailableSports() {
    console.log('🔍 מחלץ ספורטים זמינים...');
    const sportsSet = new Set();
    
    console.log('📊 מגרשים לפי זמן:', Object.keys(this.fieldsByTime).map(time => 
      `${time}: ${this.fieldsByTime[time]?.length || 0} מגרשים`
    ));
    
    Object.values(this.fieldsByTime).forEach(fields => {
      fields.forEach(field => {
        if (field.sportTypeId) {
          sportsSet.add(field.sportTypeId);
          console.log(`🏟️ מגרש: ${field.name} - ספורט: ${field.sportType} (ID: ${field.sportTypeId})`);
        } else {
          console.log(`⚠️ מגרש ללא sportTypeId: ${field.name} - ${field.sportType}`);
        }
      });
    });
    
    if (sportsSet.size === 0) {
      console.log('❌ לא נמצאו ספורטים זמינים בכלל!');
      console.log('🔍 בדיקת נתוני fieldsByTime:', JSON.stringify(this.fieldsByTime, null, 2));
    }
    
    const result = Array.from(sportsSet).sort((a, b) => a - b);
    console.log('✅ ספורטים זמינים:', result);
    return result;
  }

  // חישוב ניקוד מדויק לכל שילוב זמן-ספורט
  calculatePreciseScore(timeSlot, sportId, currentUsage = 0, priority = 1) {
    const availableFields = this.fieldsByTime[timeSlot] || [];
    const hasAvailableField = availableFields.some(field => 
      field.sportTypeId === sportId && field.isAvailable !== false
    );
    
    if (!hasAvailableField) {
      console.log(`❌ אין מגרש זמין ל-${SPORT_MAPPING[sportId]} ב-${timeSlot}`);
      return -1; // בלתי אפשרי
    }
    
    let score = 1000; // ניקוד בסיס גבוה
    
    // בונוס חזק להעדפות משתמש (סדר חשוב!)
    const preferenceIndex = this.userPreferences.indexOf(sportId);
    if (preferenceIndex !== -1) {
      score += (this.userPreferences.length - preferenceIndex) * 500;
    }
    
    // עונש חזק על עדיפות נמוכה (גיוון חשוב!)
    const priorityPenalty = (priority - 1) * 2000;
    score -= priorityPenalty;
    
    // עונש על שימוש חוזר (רק אם זה לא עדיפות ראשונה)
    if (priority > 1) {
      const usagePenalty = currentUsage * currentUsage * 100;
      score -= usagePenalty;
    }
    
    // בונוס לאיכות המגרש
    const bestField = availableFields
      .filter(field => field.sportTypeId === sportId)
      .sort((a, b) => (b.name || '').length - (a.name || '').length)[0];
    
    if (bestField && bestField.name && bestField.name.length > 10) {
      score += 50; // מגרש איכותי
    }
    
    // עונש קל על זמנים מאוחרים (העדפה לזמנים מוקדמים)
    const timeIndex = this.timeSlots.indexOf(timeSlot);
    score -= timeIndex * 2;
    
    const finalScore = Math.max(0, score);
    console.log(`🎯 ניקוד ל-${SPORT_MAPPING[sportId]} ב-${timeSlot}: ${finalScore} (בסיס: 1000, העדפה: ${preferenceIndex !== -1 ? (this.userPreferences.length - preferenceIndex) * 500 : 0}, עונש עדיפות: ${(priority - 1) * 2000}, עונש שימוש: ${priority > 1 ? currentUsage * currentUsage * 100 : 0}, עונש זמן: ${timeIndex * 2})`);
    
    return finalScore;
  }

  // יצירת מטריצת עלויות מושלמת לאלגוריתם ההונגרי
  createOptimalCostMatrix() {
    console.log('🏗️ יוצר מטריצת עלויות אופטימלית...');
    
    const numTimeSlots = this.timeSlots.length;
    console.log('📊 נתונים:', {
      numTimeSlots,
      availableSports: this.availableSports,
      userPreferences: this.userPreferences,
      fieldsByTimeKeys: Object.keys(this.fieldsByTime)
    });
    
    // יוצר "אפשרויות ספורט" - עם עדיפות לגיוון
    const sportOptions = [];
    
    console.log('🏃 יוצר אפשרויות ספורט...');
    
    // קודם כל - כל ספורט פעם ראשונה (גיוון מקסימלי)
    for (const sportId of this.availableSports) {
      sportOptions.push({
        sportId,
        usage: 0,
        id: `${sportId}_1`,
        name: `${SPORT_MAPPING[sportId]} (ראשון)`,
        priority: 1 // עדיפות גבוהה
      });
    }
    
    console.log(`✅ נוצרו ${sportOptions.length} אפשרויות ספורט ראשונות`);
    
    // אחר כך - ספורטים לא אהובים (אם אין ברירה)
    let notLikedCount = 0;
    for (const sportId of this.availableSports) {
      if (!this.userPreferences.includes(sportId)) {
        sportOptions.push({
          sportId,
          usage: 1,
          id: `${sportId}_2`,
          name: `${SPORT_MAPPING[sportId]} (לא אהוב)`,
          priority: 2 // עדיפות נמוכה
        });
        notLikedCount++;
      }
    }
    console.log(`✅ נוצרו ${notLikedCount} אפשרויות ספורט לא אהובים`);
    
    // לבסוף - חזרה על ספורטים אהובים (רק אם אין ברירה)
    let repeatCount = 0;
    for (const sportId of this.userPreferences) {
      sportOptions.push({
        sportId,
        usage: 1,
        id: `${sportId}_3`,
        name: `${SPORT_MAPPING[sportId]} (חוזר)`,
        priority: 3 // עדיפות נמוכה ביותר
      });
      repeatCount++;
    }
    console.log(`✅ נוצרו ${repeatCount} אפשרויות ספורט חוזרים`);
    
    const matrixSize = Math.max(numTimeSlots, sportOptions.length);
    console.log(`📐 גודל מטריצה: ${matrixSize}x${matrixSize}`);
    console.log(`🏃 אפשרויות ספורט: ${sportOptions.length}`);
    
    if (matrixSize === 0) {
      throw new Error('גודל מטריצה הוא 0 - אין נתונים לעיבוד');
    }
    
    const costMatrix = Array(matrixSize).fill().map(() => Array(matrixSize).fill(0));
    
    // מילוי המטריצה
    console.log('🔢 ממלא מטריצת עלויות...');
    let validAssignments = 0;
    let invalidAssignments = 0;
    
    for (let i = 0; i < matrixSize; i++) {
      for (let j = 0; j < matrixSize; j++) {
        if (i < numTimeSlots && j < sportOptions.length) {
          // זמן אמיתי ← אפשרות ספורט אמיתית
          const timeSlot = this.timeSlots[i];
          const sportOption = sportOptions[j];
          const score = this.calculatePreciseScore(timeSlot, sportOption.sportId, sportOption.usage, sportOption.priority);
          
          // המרה לעלות: ניקוד גבוה = עלות נמוכה
          costMatrix[i][j] = score === -1 ? 999999 : (10000 - score);
          
          if (score === -1) {
            invalidAssignments++;
          } else {
            validAssignments++;
          }
          
        } else if (i < numTimeSlots) {
          // זמן אמיתי ← ספורט דמה (עלות גבוהה מאוד)
          costMatrix[i][j] = 999999;
          
        } else if (j < sportOptions.length) {
          // זמן דמה ← ספורט אמיתי (עלות נמוכה)
          costMatrix[i][j] = 1;
          
        } else {
          // זמן דמה ← ספורט דמה (עלות 0)
          costMatrix[i][j] = 0;
        }
      }
    }
    
    console.log(`✅ מטריצה מולאה: ${validAssignments} השמות תקינות, ${invalidAssignments} השמות לא תקינות`);
    
    // שמירת מידע על האפשרויות למטרות דיבוג
    this.sportOptions = sportOptions;
    this.matrixSize = matrixSize;
    
    console.log('✅ מטריצת עלויות נוצרה בהצלחה');
    return costMatrix;
  }

  // פתרון הבעיה באלגוריתם הונגרי
  solveOptimal() {
    console.log('🎯 מתחיל פתרון אופטימלי מלא...');
    
    try {
      console.log('🏗️ יוצר מטריצת עלויות...');
      const costMatrix = this.createOptimalCostMatrix();
      console.log('✅ מטריצת עלויות נוצרה, גודל:', costMatrix.length + 'x' + costMatrix[0]?.length);
      
      console.log('🔢 מתחיל אלגוריתם הונגרי...');
      const hungarian = new OptimalHungarianAlgorithm(costMatrix);
      const assignment = hungarian.solve();
      
      console.log('📋 תוצאת האלגוריתם ההונגרי:', assignment);
      
      console.log('🔍 מנתח תוצאות...');
      const result = this.parseOptimalAssignment(assignment);
      console.log('✅ ניתוח תוצאות הושלם');
      
      return result;
      
    } catch (error) {
      console.error('❌ שגיאה בפתרון אופטימלי:', error);
      console.error('❌ Stack trace:', error.stack);
      throw error;
    }
  }

  // פירוק תוצאת האלגוריתם ההונגרי לתוכנית אימון
  parseOptimalAssignment(assignment) {
    console.log('🔍 מנתח תוצאת השמה אופטימלית...');
    console.log('📋 השמה:', assignment);
    console.log('🏃 אפשרויות ספורט:', this.sportOptions?.length || 0);
    
    const result = [];
    const sportsUsageCount = {};
    const usedSportOptions = new Set(); // מניעת כפילות
    let totalScore = 0;
    
    for (let i = 0; i < this.timeSlots.length; i++) {
      const timeSlot = this.timeSlots[i];
      const assignedOptionIndex = assignment[i];
      
      console.log(`🔍 מעבד זמן ${timeSlot} (אינדקס ${i}): השמה ${assignedOptionIndex}`);
      
      if (assignedOptionIndex !== -1 && 
          assignedOptionIndex < this.sportOptions.length) {
        
        const sportOption = this.sportOptions[assignedOptionIndex];
        const currentUsage = sportsUsageCount[sportOption.sportId] || 0;
        
        console.log(`🏃 ספורט מוקצה: ${sportOption.name} (שימוש ${currentUsage})`);
        
        // בדיקה אם השמה תקינה (לא כפילות באותה אופציה)
        if (!usedSportOptions.has(assignedOptionIndex)) {
          const selectedField = this.findOptimalField(timeSlot, sportOption.sportId);
          const score = this.calculatePreciseScore(timeSlot, sportOption.sportId, currentUsage);
          
          if (selectedField && score > 0) {
            sportsUsageCount[sportOption.sportId] = currentUsage + 1;
            usedSportOptions.add(assignedOptionIndex); // סימון כשימוש
            totalScore += score;
            
            result.push({
              time: timeSlot,
              field: selectedField,
              sportType: SPORT_MAPPING[sportOption.sportId],
              sportId: sportOption.sportId,
              usage: currentUsage + 1,
              score: score,
              isOptimal: true
            });
            
            console.log(`✅ ${timeSlot}: ${SPORT_MAPPING[sportOption.sportId]} (${score} נק') במגרש ${selectedField.name}`);
          } else {
            result.push({
              time: timeSlot,
              field: null,
              reason: 'לא נמצא מגרש מתאים',
              isOptimal: false
            });
            console.log(`❌ ${timeSlot}: לא נמצא מגרש ל-${SPORT_MAPPING[sportOption.sportId]}`);
          }
        } else {
          result.push({
            time: timeSlot,
            field: null,
            reason: 'ספורט זה כבר שומש',
            isOptimal: false
          });
          console.log(`⚠️ ${timeSlot}: ספורט כבר שומש`);
        }
      } else {
        result.push({
          time: timeSlot,
          field: null,
          reason: 'לא נמצא שיבוץ אופטימלי',
          isOptimal: false
        });
        console.log(`❌ ${timeSlot}: לא נמצא שיבוץ`);
      }
    }
    
    const successfulSlots = result.filter(slot => slot.field !== null).length;
    
    console.log(`🏆 פתרון אופטימלי: ${successfulSlots}/${this.timeSlots.length} זמנים`);
    console.log(`🎯 ניקוד כולל: ${totalScore}`);
    console.log(`📊 שימוש בספורטים:`, sportsUsageCount);
    
    return {
      slots: result,
      totalSlots: this.timeSlots.length,
      successfulSlots: successfulSlots,
      totalScore: totalScore,
      sportsUsage: sportsUsageCount,
      isOptimal: true,
      algorithm: 'Hungarian Algorithm (Optimal)'
    };
  }

  // מציאת המגרש האופטימלי לספורט בזמן נתון
  findOptimalField(timeSlot, sportId) {
    const availableFields = this.fieldsByTime[timeSlot] || [];
    const suitableFields = availableFields.filter(field => 
      field.sportTypeId === sportId && field.isAvailable !== false
    );
    
    console.log(`🔍 מחפש מגרש ל-${SPORT_MAPPING[sportId]} ב-${timeSlot}:`, {
      availableFields: availableFields.length,
      suitableFields: suitableFields.length
    });
    
    if (suitableFields.length === 0) {
      console.log(`❌ לא נמצא מגרש מתאים ל-${SPORT_MAPPING[sportId]} ב-${timeSlot}`);
      return null;
    }
    
    // מיון לפי איכות המגרש
    const bestField = suitableFields.sort((a, b) => {
      // העדף מגרשים עם שמות מפורטים יותר
      const scoreA = (a.name || '').length + (a.description || '').length;
      const scoreB = (b.name || '').length + (b.description || '').length;
      return scoreB - scoreA;
    })[0];
    
    console.log(`✅ נבחר מגרש: ${bestField.name} (${bestField.sportType})`);
    return bestField;
  }

  // בדיקת תקינות הנתונים לפני הפתרון
  validateInputData() {
    console.log('🔍 בודק תקינות נתונים...');
    
    const issues = [];
    
    if (!this.timeSlots || this.timeSlots.length === 0) {
      issues.push('אין זמנים מוגדרים');
    }
    
    if (!this.fieldsByTime || Object.keys(this.fieldsByTime).length === 0) {
      issues.push('אין מגרשים זמינים');
    }
    
    if (this.availableSports.length === 0) {
      issues.push('אין ספורטים זמינים');
    }
    
    // בדיקה שיש לפחות מגרש אחד זמין
    const totalFields = Object.values(this.fieldsByTime).flat().length;
    if (totalFields === 0) {
      issues.push('אין מגרשים זמינים בכלל');
    }
    
    // לוגים מפורטים יותר
    console.log('📊 נתוני בדיקה:', {
      timeSlots: this.timeSlots?.length || 0,
      fieldsByTimeKeys: Object.keys(this.fieldsByTime || {}).length,
      availableSports: this.availableSports?.length || 0,
      totalFields,
      userPreferences: this.userPreferences?.length || 0
    });
    
    if (issues.length > 0) {
      console.log('❌ בעיות בנתונים:', issues);
      return { valid: false, issues };
    }
    
    console.log('✅ נתונים תקינים');
    return { valid: true, issues: [] };
  }

  // פונקציה ראשית לפתרון
  solve() {
    console.log('🚀 מתחיל פתרון בעיית שיבוץ אופטימלי מלא...');
    
    try {
      // בדיקת תקינות
      console.log('🔍 בודק תקינות נתונים...');
      const validation = this.validateInputData();
      if (!validation.valid) {
        throw new Error(`נתונים לא תקינים: ${validation.issues.join(', ')}`);
      }
      console.log('✅ נתונים תקינים');
      
      // פתרון אופטימלי
      console.log('🎯 מתחיל פתרון אופטימלי...');
      const result = this.solveOptimal();
      
      console.log('🏆 פתרון אופטימלי הושלם בהצלחה!');
      return result;
      
    } catch (error) {
      console.error('❌ שגיאה בפתרון אופטימלי:', error);
      console.error('❌ Stack trace:', error.stack);
      console.error('❌ נתוני הקלט:', {
        timeSlots: this.timeSlots?.length,
        fieldsByTime: Object.keys(this.fieldsByTime || {}).length,
        userPreferences: this.userPreferences?.length,
        availableSports: this.availableSports?.length
      });
      throw new Error(`שגיאה בפתרון אופטימלי: ${error.message}`);
    }
  }
}

module.exports = {
  OptimalHungarianAlgorithm,
  CompleteOptimalWorkoutScheduler,
  SPORT_MAPPING
};
